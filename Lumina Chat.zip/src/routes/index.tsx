import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { Bot, Send, Sparkles, Trash2, User } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nova — AI Chatbot" },
      { name: "description", content: "A modern rule-based AI chatbot with a sleek glassmorphism interface." },
      { property: "og:title", content: "Nova — AI Chatbot" },
      { property: "og:description", content: "A modern rule-based AI chatbot with a sleek glassmorphism interface." },
    ],
  }),
  component: ChatPage,
});

type Role = "user" | "bot";
interface Message {
  id: string;
  role: Role;
  content: string;
  timestamp: number;
}

const RULES: { patterns: string[]; reply: string }[] = [
  { patterns: ["hello"], reply: "Hello! How can I help you today?" },
  { patterns: ["hi"], reply: "Hi there! Nice to meet you." },
  { patterns: ["how are you"], reply: "I'm doing great. How about you?" },
  { patterns: ["what is ai"], reply: "Artificial Intelligence is the simulation of human intelligence in machines." },
  { patterns: ["who created you"], reply: "I am a rule-based chatbot developed for an AI internship project." },
  { patterns: ["bye"], reply: "Goodbye! Have a wonderful day." },
  { patterns: ["thank you", "thanks"], reply: "You're welcome!" },
];

const FALLBACK = "I'm a simple rule-based bot. Try: \"hello\", \"how are you\", \"what is ai\", \"who created you\", \"thank you\", or \"bye\".";

function getReply(input: string): string {
  const text = input.toLowerCase().trim();
  for (const rule of RULES) {
    if (rule.patterns.some((p) => text.includes(p))) return rule.reply;
  }
  return FALLBACK;
}

const welcomeMessage = (): Message => ({
  id: crypto.randomUUID(),
  role: "bot",
  content: "Hi! I'm Nova, a friendly rule-based assistant. Ask me something like \"what is ai\" or just say hello.",
  timestamp: Date.now(),
});

function formatTime(ts: number) {
  return new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([welcomeMessage()]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isTyping]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    setError(null);

    if (!trimmed) {
      setError("Please type a message before sending.");
      return;
    }
    if (trimmed.length > 500) {
      setError("Message too long (max 500 characters).");
      return;
    }

    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content: trimmed,
      timestamp: Date.now(),
    };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setIsTyping(true);

    const delay = 600 + Math.random() * 600;
    window.setTimeout(() => {
      try {
        const reply = getReply(trimmed);
        const botMsg: Message = {
          id: crypto.randomUUID(),
          role: "bot",
          content: reply,
          timestamp: Date.now(),
        };
        setMessages((m) => [...m, botMsg]);
      } catch {
        setError("Something went wrong generating a reply. Please try again.");
      } finally {
        setIsTyping(false);
        inputRef.current?.focus();
      }
    }, delay);
  };

  const handleClear = () => {
    setMessages([welcomeMessage()]);
    setError(null);
    inputRef.current?.focus();
  };

  return (
    <main className="flex min-h-screen flex-col items-center px-3 py-4 sm:px-6 sm:py-8">
      <div className="flex w-full max-w-3xl flex-1 flex-col gap-4">
        {/* Header */}
        <header className="glass-panel grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-2xl px-4 py-3 sm:px-5">
          <div className="flex min-w-0 items-center gap-3">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl btn-primary-gradient animate-pulse-glow">
              <Sparkles className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <h1 className="truncate text-lg font-bold sm:text-xl">
                <span className="gradient-text">Nova</span> AI Chat
              </h1>
              <p className="truncate text-xs text-muted-foreground">Rule-based assistant · Always online</p>
            </div>
          </div>
          <button
            onClick={handleClear}
            className="glass-panel inline-flex shrink-0 items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-foreground transition hover:bg-white/10"
            aria-label="Clear chat"
          >
            <Trash2 className="h-4 w-4" />
            <span className="hidden sm:inline">Clear</span>
          </button>
        </header>

        {/* Chat area */}
        <section className="glass-panel relative flex flex-1 flex-col overflow-hidden rounded-3xl">
          <div
            ref={scrollRef}
            className="chat-scroll flex-1 space-y-4 overflow-y-auto px-3 py-5 sm:px-6"
            style={{ maxHeight: "calc(100vh - 240px)", minHeight: "50vh" }}
          >
            {messages.map((m) => (
              <MessageBubble key={m.id} message={m} />
            ))}
            {isTyping && <TypingIndicator />}
          </div>

          {/* Composer */}
          <div className="border-t border-white/10 bg-white/5 p-3 sm:p-4">
            {error && (
              <p className="mb-2 px-1 text-xs text-destructive animate-message-in" role="alert">
                {error}
              </p>
            )}
            <form onSubmit={handleSubmit} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type a message…"
                maxLength={500}
                aria-label="Message"
                className="min-w-0 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/60 focus:bg-white/10 focus:ring-2 focus:ring-primary/40"
              />
              <button
                type="submit"
                disabled={!input.trim() || isTyping}
                className="btn-primary-gradient inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl"
                aria-label="Send message"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
            <p className="mt-2 px-1 text-[10px] text-muted-foreground">
              {input.length}/500 · Press Enter to send
            </p>
          </div>
        </section>

        <footer className="text-center text-xs text-muted-foreground">
          Built with React + Tailwind · Rule-based responses
        </footer>
      </div>
    </main>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";
  const [time, setTime] = useState("");
  useEffect(() => {
    setTime(formatTime(message.timestamp));
  }, [message.timestamp]);
  return (
    <div className={`flex items-end gap-2 animate-message-in ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full btn-primary-gradient">
          <Bot className="h-4 w-4" />
        </div>
      )}
      <div className={`flex max-w-[78%] flex-col gap-1 ${isUser ? "items-end" : "items-start"}`}>
        <div
          className={
            isUser
              ? "rounded-2xl rounded-br-sm bg-[var(--user-bubble)] px-4 py-2.5 text-sm text-[var(--user-bubble-foreground)] shadow-[var(--shadow-glow)]"
              : "glass-panel rounded-2xl rounded-bl-sm px-4 py-2.5 text-sm text-foreground"
          }
        >
          <p className="whitespace-pre-wrap break-words leading-relaxed">{message.content}</p>
        </div>
        <span className="px-1 text-[10px] text-muted-foreground min-h-[14px]" suppressHydrationWarning>{time}</span>
      </div>
      {isUser && (
        <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-white/10 bg-white/10">
          <User className="h-4 w-4" />
        </div>
      )}
    </div>
  );
}

function TypingIndicator() {
  return (
    <div className="flex items-end gap-2 animate-message-in">
      <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full btn-primary-gradient">
        <Bot className="h-4 w-4" />
      </div>
      <div className="glass-panel flex items-center gap-1.5 rounded-2xl rounded-bl-sm px-4 py-3">
        <span className="h-2 w-2 rounded-full bg-primary animate-typing" style={{ animationDelay: "0ms" }} />
        <span className="h-2 w-2 rounded-full bg-primary animate-typing" style={{ animationDelay: "150ms" }} />
        <span className="h-2 w-2 rounded-full bg-primary animate-typing" style={{ animationDelay: "300ms" }} />
      </div>
    </div>
  );
}
